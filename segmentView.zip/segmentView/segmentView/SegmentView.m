//
//  SegmentView.m
//  segmentView
//
//  Created by mac on 2018/9/13.
//  Copyright © 2018年 mac. All rights reserved.
//

#import "SegmentView.h"
#import "UIView+Border.h"
#define KCWidth [UIScreen mainScreen].bounds.size.width
#define KCHeight [UIScreen mainScreen].bounds.size.height
@interface SegmentView(){
    // 存放segment控件的标题
    NSMutableArray *_titles;
}

@end

@implementation SegmentView

- (instancetype)initWithFrame:(CGRect)frame titles:(NSArray *)titles{
    if (self = [super initWithFrame:frame]) {
        _titles = titles.mutableCopy;
        self.titlesView = [NSMutableArray array];
        self.bottomsView = [NSMutableArray array];
        [self setSegmnetViewUIWithFrame:frame];
    }
    return self;
}


#pragma mark - 初始化设置segmentView

- (void)setSegmnetViewUIWithFrame:(CGRect)frame{
    
    
    //移除之前的数据
    if (self.titlesView.count) {
        [self.titlesView removeAllObjects];
        [self.bottomsView removeAllObjects];
    }
    //移除之前控件
    for (UIView *view in self.subviews) {
        if ([view isKindOfClass:[UIView class]]) {
            [view removeFromSuperview];
        }
    }
    
    CGFloat viewW = frame.size.width / _titles.count;
    CGFloat itemX = 0;
    CGFloat itemY = 0;
    CGFloat itemW = frame.size.width / _titles.count - 1;
    CGFloat itemH = 40;
    CGFloat bottomW = frame.size.width / _titles.count - 20;
    for (int i = 0; i < _titles.count; i++) {
        
        //1、设置UIView控件
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(itemX + viewW * i, itemY,viewW, itemH + 1.5)];
        view.backgroundColor = [UIColor whiteColor];
        [self addSubview:view];
        
        [UIView setViewBorder:self color:[UIColor grayColor] border:0.5 type:UIViewBorderLineTypeTop];
//        if (i == 0) {
//            [UIView setViewBorder:self color:[UIColor blueColor] border:0.5 type:UIViewBorderLineTypeLeft];
//        }else if (i == _titles.count - 1){
//            [UIView setViewBorder:self color:[UIColor blueColor] border:0.5 type:UIViewBorderLineTypeRight];
//        }

        //2、设置button控件
        UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0,viewW, itemH)];
        [btn setTitle:_titles[i] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(clickBtn:) forControlEvents:UIControlEventTouchUpInside];
        btn.tag = 100 + i;
        btn.backgroundColor = [UIColor whiteColor];
        //设置默认位置的button的title颜色
        if (i == 0){
            [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        }else{
            [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        }
        [view addSubview:btn];
        [self.titlesView addObject:btn];
        
        
        //3、设置UILabel控件
        UILabel *bottomLine = [[UILabel alloc] initWithFrame:CGRectMake(0 + 20, itemH, bottomW - 20, 1.5)];
        if (i == 0) {
            bottomLine.backgroundColor = [UIColor redColor];
        }else{
            bottomLine.backgroundColor = [UIColor whiteColor];
        }
        [view addSubview:bottomLine];
        [self.bottomsView addObject:bottomLine];
        
        //4、添加分割线
        if (i == _titles.count - 1) {
            return;
        }
        UIView *fglineV = [[UIView alloc] initWithFrame:CGRectMake(itemW, 7.5, 0.5, 25)];
        fglineV.backgroundColor = [UIColor grayColor];
        [view addSubview:fglineV];
    }
    
}

#pragma mark - 根据的titles设置视图

- (void)setSegmentUIWithTitles:(NSArray *)titles currenIndex:(NSInteger)index
{
    if (titles.count == 0) return;
    [_titles removeAllObjects];
    _titles = titles.mutableCopy;
    [self setSegmnetViewUIWithFrame:self.frame];
}



#pragma mark - 切换视图设置样式

- (void)setSegmentUIWithIndex:(NSInteger)index{
    
    [self setSegmentStyleIndex:index];
}


#pragma mark - 重新设置segment的样式

- (void)setSegmentStyleIndex:(NSInteger)index
{
    //当前的labels和buttons不相等
    if (self.titlesView.count != self.bottomsView.count) {
        //设置标题button的颜色
        for (int i = 0; i < self.titlesView.count; i ++) {
            //循环设置控件UIButton的背景颜色
            UIButton *btn = self.titlesView[i];
            btn.backgroundColor = [UIColor grayColor];
            [btn setTitle:_titles[i] forState:UIControlStateNormal];
            if (index == i) {
                [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
            }else{
                [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            }
        }
        
        //设置底部UILabel颜色
        for (int i = 0; i < self.bottomsView.count; i ++) {
            UILabel *bottomLine = self.bottomsView[i];
            if (index == i) {
                bottomLine.backgroundColor = [UIColor redColor];
            }else{
                bottomLine.backgroundColor = [UIColor whiteColor];
            }
        }
    }
    
    //labels和buttons数量相等
    else{
        for (int i = 0;  i < _titles.count; i ++) {
            UIButton *btn = self.titlesView[i];
            UILabel *lable = self.bottomsView[i];
            [btn setTitle:_titles[i] forState:UIControlStateNormal];
            if (i == index) {
                [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
                lable.backgroundColor = [UIColor redColor];
            }else{
                [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
                lable.backgroundColor = [UIColor whiteColor];
            }
            
        }
    }
}


#pragma mark - 点击回调方法

- (void)selectedIndexBlock:(SelectedIndex)selectedIndexBlock
{
    self.selectedBlock = selectedIndexBlock;
}

- (void)clickBtn:(UIButton *)sender{
    //1、使用block回调
//    if (self.selectedBlock) {
//        self.selectedBlock(sender.tag - 100);
//    }
    
    //2、使用代理回调
    if (self.delegate && [self.delegate respondsToSelector:@selector(clickSegmentView:clickIndex:)]) {
        [self.delegate clickSegmentView:sender clickIndex:sender.tag - 100];
    }
}

@end

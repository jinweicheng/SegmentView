//
//  ViewController.m
//  segmentView
//
//  Created by mac on 2018/9/13.
//  Copyright © 2018年 mac. All rights reserved.
//

#import "ViewController.h"
#import "SegmentView.h"

#define KCWidth [UIScreen mainScreen].bounds.size.width
#define KCHeight [UIScreen mainScreen].bounds.size.height
@interface ViewController ()<SegmentViewDelegate>

@property (nonatomic, strong)  SegmentView *seg;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.seg = [[SegmentView alloc] initWithFrame:CGRectMake(0, 100, KCWidth, 40) titles:@[@"ceshi1",@"ceshi2",@"ceshi3"]];
    self.seg.delegate = self;
    __weak typeof(self) weakSelf = self;
//    [self.seg selectedIndexBlock:^(NSInteger index) {
////        __strong typeof(weakSelf) strongSelf = weakSelf;
//        NSLog(@"index==%zd",index);
//        [weakSelf.seg setSegmentUIWithIndex:index];
//    }];
    [self.view addSubview:self.seg];


}



- (void)clickSegmentView:(UIButton *)sender clickIndex:(NSInteger)index
{
    [self.seg setSegmentUIWithIndex:index];

}

//- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
//{
//    [self.seg setSegmentUIWithTitles:@[@"1",@"2",@"3",@"4"] currenIndex:0];
//}






@end

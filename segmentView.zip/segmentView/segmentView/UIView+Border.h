

//
//  UIView+Border.h
//  segmentView
//
//  Created by mac on 2018/10/11.
//  Copyright © 2018年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, UIViewBorderLineType) {
    UIViewBorderLineTypeTop,
    UIViewBorderLineTypeRight,
    UIViewBorderLineTypeBottom,
    UIViewBorderLineTypeLeft,
};

@interface UIView (Border)

+ (void)setViewBorder:(UIView *)view color:(UIColor *)color radius:(float)radius border:(float)border;

+ (void)setViewBorder:(UIView *)view color:(UIColor *)color border:(float)border type:(UIViewBorderLineType)borderLineType; 

@end

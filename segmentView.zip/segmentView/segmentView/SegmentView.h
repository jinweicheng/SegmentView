//
//  SegmentView.h
//  segmentView
//
//  Created by mac on 2018/9/13.
//  Copyright © 2018年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^SelectedIndex)(NSInteger index);
@protocol SegmentViewDelegate <NSObject>
@required
- (void)clickSegmentView:(UIButton *)sender clickIndex:(NSInteger)index;
@end

@interface SegmentView : UIView
@property (nonatomic, strong)  NSArray<NSString *> *titles;               /**< 设置标题设置 */
@property (nonatomic, strong)  NSMutableArray *titlesView;                /**< 存放标题视图控件 */
@property (nonatomic, strong)  NSMutableArray *bottomsView;               /**< 存放底部视图控件 */
@property (nonatomic, weak)  id<SegmentViewDelegate> delegate;            /**< 代理方法 */
@property (nonatomic, assign)  SelectedIndex selectedBlock;               /**< 选中下标 */
/**< block选中的下标 */
- (void)selectedIndexBlock:(SelectedIndex)selectedIndexBlock;
/**< 初始化segment */
- (instancetype)initWithFrame:(CGRect)frame titles:(NSArray *)titles;
/**< 点击切换segment的样式 ,titles数据没有变化 */
- (void)setSegmentUIWithIndex:(NSInteger)index;
/**< 根据titles设置segment的样式，titles数据变化 */
- (void)setSegmentUIWithTitles:(NSArray *)titles currenIndex:(NSInteger)index;
@end
